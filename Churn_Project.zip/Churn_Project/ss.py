import mysql.connector

try:
    conn = mysql.connector.connect(
        host='localhost',
        user='root',
        password='Rohan+9620',
        database='churn_predictions'
    )
    cursor = conn.cursor()

    insert_query = """
    INSERT INTO prediction_logs (
        customerID, SeniorCitizen, MonthlyCharges, TotalCharges, gender, Partner, Dependents,
        PhoneService, MultipleLines, InternetService, OnlineSecurity, OnlineBackup,
        DeviceProtection, TechSupport, StreamingTV, StreamingMovies, Contract,
        PaperlessBilling, PaymentMethod, tenure, prediction, confidence
    )
    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
    """

    values = (
        customerID,
        input_data[0], input_data[1], input_data[2], input_data[3], input_data[4],
        input_data[5], input_data[6], input_data[7], input_data[8], input_data[9],
        input_data[10], input_data[11], input_data[12], input_data[13], input_data[14],
        input_data[15], input_data[16], input_data[17], input_data[18],
        int(prediction[0]), round(float(probability[0]) * 100, 2)
    )

    cursor.execute(insert_query, values)
    conn.commit()

except Exception as db_err:
    print("Database insert error:", db_err)

finally:
    if conn.is_connected():
        cursor.close()
        conn.close()
